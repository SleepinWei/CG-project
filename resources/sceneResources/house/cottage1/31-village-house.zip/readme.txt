© copyright 2018 illuminachos
- GUIDE -

animation/modelling software (Blender, 3DS Max, Maya, etc.)
	It is best to not use the 3DS version of the model as that is for game engines. If it is not visible, try bringing the transparency down.

game engine (Unity3D, Unreal 4, etc.)
	Use the 3DS version as game engines do not support normals for two sides. If you do not use the 3DS version, the model will only be visible from the outside and not the inside.

- LINKS -
youtube - illuminachosTV
twitter - illuminachosTV
